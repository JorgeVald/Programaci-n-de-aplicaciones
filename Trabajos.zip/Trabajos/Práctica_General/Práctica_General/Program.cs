﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_General
{
    class Program
    {
        static void Main(string[] args)
        {
            Ballena b = new Ballena();//se crea una instancia de la clase Ballena
            b.nadar();//se llama el método nadar
            b.respirar();//se llama el método respirar
            b.cuidarCrias();//se llama el método cuidar crias
            b.getNombre("Willy");//se llama el método nombre y se asigna un nombre
            b.mos();//se muestra el nombre
            b.pensar();//se llama el método pensar
            Console.WriteLine("\n");//da un espacio entre instrucciones

            Caballo c = new Caballo();//se crea una instancia de la clase Caballo
            c.galopar();//se llama el método galopar
            c.respirar();//se llama el método respirar
            c.cuidarCrias();//se llama el método cuidar crias
            c.getNombre("James");//se llama el método nombre y se asigna un nombre
            c.mos();//se muestra el nombre
            c.numeroPatas(4);//llama el método de numeroPatas y asigna el número de patas al animal
            c.mostrar();//muestra el número de patas
            c.pensar();//se llama el método pensar
            Console.WriteLine("\n");//da un espacio entre instrucciones

            Gorila g = new Gorila();//se crea una instancia de la clase Gorila
            g.trepar();//se llama el método trepar
            g.respirar();//se llama el método respirar
            g.cuidarCrias();//se llama el método cuidar crias
            g.getNombre("Oranguru");//se llama el método nombre y se asigna un nombre
            g.mos();//se muestra el nombre
            g.numeroPatas(2);//llama el método de numeroPatas y asigna el número de patas al animal
            g.mostrar();//muestra el número de patas
            g.pensar();//se llama el método pensar
            Console.WriteLine("\n");//da un espacio entre instrucciones

            Humano h = new Humano();//se crea una instancia de la clase Humano
            h.pensar();//se llama el método pensar
            h.respirar();//se llama el método respirar
            h.cuidarCrias();//se llama el método cuidar crias
            h.getNombre("Miguel");//se llama el método nombre y se asigna un nombre
            h.mos();//se muestra el nombre
            h.numeroPatas(2);//llama el método de numeroPatas y asigna el número de patas al animal
            h.mostrar();//muestra el número de patas
            Console.WriteLine("\n");//da un espacio entre instrucciones

            Lagartija l = new Lagartija();//se crea una instancia de la clase Lagartija
            l.getNombre("Rango");//se llama el método nombre y se asigna un nombre
            l.mos();//se muestra el nombre
            l.respirar();//se llama el método respirar
            l.numeroPatas(4);//llama el método de numeroPatas y asigna el número de patas al animal
            l.mostrar();//muestra el número de patas
            Console.ReadKey();//evita que se cierre el programa
        }
    }
}
