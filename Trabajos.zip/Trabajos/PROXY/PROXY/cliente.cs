﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROXY
{
    class cliente
    {
        static void Main()
        {
            cproxy roxy = new cproxy();
            Console.WriteLine(roxy.Request());

            Console.Read();
        }
    }
}
