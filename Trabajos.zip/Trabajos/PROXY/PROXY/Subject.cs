﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROXY
{
    class Subject : ISubject
    {
        public string Request()
        {
            return "Llamando al Subject.Request()";
        }
    }
}
