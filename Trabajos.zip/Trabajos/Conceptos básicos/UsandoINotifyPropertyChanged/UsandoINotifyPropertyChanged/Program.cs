﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace UsandoINotifyPropertyChanged
{
    class Program
    {
        static void Main(string[] args)
        {
            estudiante s= new estudiante("Jorge",20);
            s.PropertyChanged += aluno_PropertyChanged;
            s.nombre = "Francisco Ismael";
            s.alterarNota();
            s.nota = 8;
            Console.ReadLine();
        }
        private static void aluno_PropertyChanged(Object sender, PropertyChangedEventArgs e)
        {
            Console.WriteLine(string.Format ("Propiedad {0} sólo se ha cambiado ", e.PropertyName));
        }
    }
}
