﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Here2
{
    class ClasePadre
    {
        public void Saludar()
        {
            Console.WriteLine("Hola...");
        }

        public void Despedirse()
        {
            Console.WriteLine("Adiós!...");
        }
    }
}
