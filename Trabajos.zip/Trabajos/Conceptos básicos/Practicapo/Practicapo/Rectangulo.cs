﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practicapo
{
    class Rectangulo
    {
        public void Area(int Base, int Altura)
        {
            Console.WriteLine("El área de mi rectángulo es: " + (Base * Altura));
        }
    }
}
