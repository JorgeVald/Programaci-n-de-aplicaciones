﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            CSuma s = new CSuma();
            s.calcular(10,20.3);
            s.mostrar();
            //s.muestraResultados();

            CResta re = new CResta();
            CDivision d = new CDivision();
            CMulti m = new CMulti();
            re.calcular(10, 20.3);
            re.mostrar();

            d.calcular(10, 20.3);
            d.mostrar();

            m.calcular(10, 20.3);
            m.mostrar();

        }
    }
}
